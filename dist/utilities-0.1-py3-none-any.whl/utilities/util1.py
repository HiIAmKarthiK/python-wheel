def sayHi():
    print('Hi, I am one of utilities, yes')